var express = require('express'),
router = express.Router();

router
  // Add a binding to handle '/order'
  .get('/', function(req, res){
    res.render('order');
  })

module.exports = router;