var express = require('express'),
    MongoClient = require('mongodb').MongoClient;
var url = "mongodb://localhost:27017";
const client = new MongoClient(url);


router = express.Router();

router
    // Add a binding to handle '/order'
    .get('/', function (req, res) {
        let items;
        client.connect().then(() => {
            console.log('Connected Successfully!')
            var dbo = client.db("GallaryDB").collection("Gallery").find().toArray().then(docs => {
                items = docs;
               // console.log(docs);
                res.render('order', { contents: docs });
            })
        }).catch(error => { console.log('Failed to connect', error); res.render('order'); });

    })


router.post('/', function (req, res) {
console.log(req);
console.log(res);
    client.connect().then(() => {
        console.log('Connected Successfully!')
        var dbo = client.db("GallaryDB").collection("Gallery").updateOne({_id : "6436145441e19ddc501958d8"},
        {$set: { "STATUS" : "S"}}).then((res) => {
            console.log(res);
        })
    }).catch(error => { console.log('Failed to connect', error); });
})

module.exports = router;