const express = require('express');
const exphbs = require('express-handlebars');
const readline = require('linebyline');

const path = require('path');
const fs = require('fs');
let port = 3000;
const app = express();

app.use(express.urlencoded());
let rawdata = fs.readFileSync('user.json');

var orderRoutes = require('./order');
app.engine('handlebars', exphbs.engine());
app.set('view engine', 'handlebars');

app.use('/order', orderRoutes);

app.get('/login', function (req, res) {
    res.render('login');
})

app.post('/login', function (req, res) {
    let clientResponse = req.body;
    let users = JSON.parse(rawdata);
    let keys = Object.keys(users);
    let arrValues = Object.values(users);
    let userValidated = false;
    let userNameCorrect = false;
    for (let i = 0; i < keys.length; i++) {
        if (clientResponse.username == keys[i]) {
            userNameCorrect = true;
            if (clientResponse.password == arrValues[i]) {
                res.cookie("username", clientResponse.username);
                return res.redirect('/');
            }
        }
    }
    if (!userValidated && userNameCorrect) {
        return res.redirect('/login?result=invalidPassword');
    }
    else if (!userValidated && !userNameCorrect) {
        return res.redirect('/login?result=invalidUserName');
    }
})

app.get('/', function (req, res) {
    if (req.headers.cookie != null) {
        let cookies = {};
        const cookiesArray = req.headers.cookie.split(';');
        cookiesArray.forEach((cookie) => {
            const [key, value] = cookie.trim().split('=');
            cookies[key] = value;
        });

        let userName = cookies["username"];
        if (userName != null && userName != '') {

            let image = req.query.image || "bedroom";
            let imageNames = [];
            r = readline('images.txt');
            r.on('line', (line) => {
                imageNames.push({ "name": line });
            })
            res.render('index', { names: imageNames, image: image });
        }
        else {
            res.redirect('login');
        }
    }
    else {
        res.redirect('login');
    }
});

app.get('/register', function (req, res) {
    res.render('register');
})

app.use('/static', express.static(path.join(__dirname, 'public')));

app.listen(port, console.log(`Listening on port ${port}`));